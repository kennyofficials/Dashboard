module.exports = {
  prefix: "!",
	owners: ["402490971041824768"],
}