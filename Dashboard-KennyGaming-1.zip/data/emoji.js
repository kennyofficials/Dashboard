module.exports = {
  x: "<:wrong:822379358453891123>",
  fail: "<:wrong:822379358453891123> ",
  check: "<:check:822377045236514816> ",
  success: "<:check:822377045236514816> ",
  cash: "$"
}