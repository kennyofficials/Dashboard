module.exports = [
  //"cow","chicken","sheep","duck","bear","chipmunk","cat","dog","koala","lion","tiger","panda","crab","cockapoo","clownfish","donkey","owl","dolphin","shark","eel","fish","seal","gecko","goose","pig","horse","hamster","iguana","kangaroo","ocelot","octopus"
{
  item: "cow",
},
{
  item: "chicken",
},
{
  item: "sheep",
},
{
  item: "duck",
},
{
  item: "bear",
},
{
  item: "chipmunk",
},
{
  item: "cat",
},
{
  item: "dog",
},
{
  item: "koala",
},
{
  item: "lion",
},
{
  item: "tiger",
},
{
  item: "panda",
},
{
  item: "crab",
},
{
  item: "cockapoo",
},
{
  item: "clownfish",
},
{
  item: "donkey",
},
{
  item: "owl"
},
{
  item: "dolphin"
},
{
  item: "shark"
},
{
  item: "eel"
},
{
  item: "fish"
},
{
  item: "seal"
},
{
  item: "gecko"
},
{
  item: "goose"
},
{
  item: "pig"
},
{
  item: "horse"
},
{
  item: "hamster"
},
{
  item: "iguana"
},
{
  item: "kangaroo"
},
{
  item: "ocelot"
},
{
  item: "octopus"
}
]