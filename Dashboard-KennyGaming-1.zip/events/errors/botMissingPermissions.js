const Event = require('../../structures/Event');
const permissions = require('../../assets/json/permissions.json');
const { MessageEmbed } = require('discord.js');
module.exports = class extends Event {

  async run(permissions, message) {
    if (!message) return;
   

  }
};