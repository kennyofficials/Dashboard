module.exports = {
 "verification": "",
 "description": "Pogy is a multi-purpose discord bot ready to skill up and boost up your Discord server!",
 "domain": "https://dashboard.bobroblox2020.repl.co/", // domain
 "google_analitics": "", // google analitics
 "token": process.env.TOKEN,
 "https":"https://", // leave as is
 "port":"5003",

 "client_id":"891005233008889887", // bot client ID
 "secret":"DVGD4r-JCwb_RLwBa6Hgwg52gYOn9tBd" // bot client secret for auth

}


// for dashboard, read more on https://github.com/IgorKowalczyk/majobot
